/********************************************************************************
** Form generated from reading UI file 'loginpage.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINPAGE_H
#define UI_LOGINPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginPage
{
public:
    QWidget *centralwidget;
    QPushButton *loginbutton;
    QCheckBox *kmsi;
    QWidget *greenTop;
    QLabel *untlogo;
    QWidget *whiteBack;
    QLabel *manageID;
    QLabel *stuhdnum;
    QLabel *fachdnum;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QLabel *IDlabel;
    QLineEdit *idtextbox;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_2;
    QLabel *passtextbox;
    QLineEdit *idtestbox_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LoginPage)
    {
        if (LoginPage->objectName().isEmpty())
            LoginPage->setObjectName("LoginPage");
        LoginPage->resize(800, 600);
        centralwidget = new QWidget(LoginPage);
        centralwidget->setObjectName("centralwidget");
        loginbutton = new QPushButton(centralwidget);
        loginbutton->setObjectName("loginbutton");
        loginbutton->setGeometry(QRect(411, 271, 91, 41));
        loginbutton->setMouseTracking(true);
        loginbutton->setTabletTracking(true);
        kmsi = new QCheckBox(centralwidget);
        kmsi->setObjectName("kmsi");
        kmsi->setGeometry(QRect(411, 331, 131, 20));
        greenTop = new QWidget(centralwidget);
        greenTop->setObjectName("greenTop");
        greenTop->setGeometry(QRect(1, 1, 801, 211));
        untlogo = new QLabel(greenTop);
        untlogo->setObjectName("untlogo");
        untlogo->setGeometry(QRect(240, 0, 261, 211));
        untlogo->setTabletTracking(false);
        untlogo->setAlignment(Qt::AlignCenter);
        whiteBack = new QWidget(centralwidget);
        whiteBack->setObjectName("whiteBack");
        whiteBack->setGeometry(QRect(0, 210, 801, 361));
        manageID = new QLabel(whiteBack);
        manageID->setObjectName("manageID");
        manageID->setGeometry(QRect(250, 170, 161, 16));
        stuhdnum = new QLabel(whiteBack);
        stuhdnum->setObjectName("stuhdnum");
        stuhdnum->setGeometry(QRect(480, 240, 191, 16));
        fachdnum = new QLabel(whiteBack);
        fachdnum->setObjectName("fachdnum");
        fachdnum->setGeometry(QRect(480, 270, 231, 16));
        manageID->raise();
        fachdnum->raise();
        stuhdnum->raise();
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(251, 251, 137, 111));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        IDlabel = new QLabel(layoutWidget);
        IDlabel->setObjectName("IDlabel");

        verticalLayout->addWidget(IDlabel);

        idtextbox = new QLineEdit(layoutWidget);
        idtextbox->setObjectName("idtextbox");
        idtextbox->setTabletTracking(true);

        verticalLayout->addWidget(idtextbox);


        verticalLayout_3->addLayout(verticalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        passtextbox = new QLabel(layoutWidget);
        passtextbox->setObjectName("passtextbox");

        verticalLayout_2->addWidget(passtextbox);

        idtestbox_2 = new QLineEdit(layoutWidget);
        idtestbox_2->setObjectName("idtestbox_2");
        idtestbox_2->setTabletTracking(true);

        verticalLayout_2->addWidget(idtestbox_2);


        verticalLayout_3->addLayout(verticalLayout_2);

        LoginPage->setCentralWidget(centralwidget);
        whiteBack->raise();
        loginbutton->raise();
        kmsi->raise();
        greenTop->raise();
        layoutWidget->raise();
        menubar = new QMenuBar(LoginPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 22));
        LoginPage->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginPage);
        statusbar->setObjectName("statusbar");
        LoginPage->setStatusBar(statusbar);

        retranslateUi(LoginPage);

        QMetaObject::connectSlotsByName(LoginPage);
    } // setupUi

    void retranslateUi(QMainWindow *LoginPage)
    {
        LoginPage->setWindowTitle(QCoreApplication::translate("LoginPage", "LoginPage", nullptr));
        loginbutton->setText(QCoreApplication::translate("LoginPage", "LOGIN", nullptr));
        kmsi->setText(QCoreApplication::translate("LoginPage", "Keep me signed in", nullptr));
        untlogo->setText(QCoreApplication::translate("LoginPage", "TextLabel", nullptr));
        manageID->setText(QCoreApplication::translate("LoginPage", "Manage EUID and password", nullptr));
        stuhdnum->setText(QCoreApplication::translate("LoginPage", "Student", nullptr));
        fachdnum->setText(QCoreApplication::translate("LoginPage", "Faculty", nullptr));
        IDlabel->setText(QCoreApplication::translate("LoginPage", "EUID", nullptr));
        idtextbox->setText(QString());
        passtextbox->setText(QCoreApplication::translate("LoginPage", "PASSWORD", nullptr));
        idtestbox_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class LoginPage: public Ui_LoginPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINPAGE_H
